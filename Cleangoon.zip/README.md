# Trabalho A4 de Programação de Jogos Digitais

## Backlog
### Semana 1: 
Terminar o GDD, idealizar e conceitualizar o jogo.

### Semana 2:
Terminar as principais entidades do jogo: Peixes, Lixos e Player
